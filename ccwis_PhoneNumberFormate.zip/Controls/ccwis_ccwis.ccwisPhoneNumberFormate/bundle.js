/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ccwisPhoneNumberFormate/index.ts"
/*!******************************************!*\
  !*** ./ccwisPhoneNumberFormate/index.ts ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ccwisPhoneNumberFormate: () => (/* binding */ ccwisPhoneNumberFormate)\n/* harmony export */ });\nclass ccwisPhoneNumberFormate {\n  // Constructor with comment\n  constructor() {\n    // Notification ID (No type annotation to satisfy ESLint)\n    this._notificationId = \"ccwis_phone_error\";\n    // Track if user is typing (No type annotation to satisfy ESLint)\n    this._isEditing = false;\n    // Empty constructor\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._inputElement = document.createElement(\"input\");\n    this._inputElement.setAttribute(\"type\", \"text\");\n    this._inputElement.className = \"ccwis-phone-input\";\n    this._inputElement.placeholder = \"(---) --- - ----\";\n    // Load initial value\n    var rawValue = context.parameters.phoneNumber.raw || \"\";\n    this._value = this.formatPhoneNumber(rawValue);\n    this._inputElement.value = this._value;\n    // Run validation immediately\n    this.validateNumber(this._value);\n    // Bind events\n    this._inputElement.addEventListener(\"input\", this.onInput.bind(this));\n    this._inputElement.addEventListener(\"focus\", this.onFocus.bind(this));\n    this._inputElement.addEventListener(\"blur\", this.onBlur.bind(this));\n    container.appendChild(this._inputElement);\n  }\n  updateView(context) {\n    this._context = context;\n    // CRITICAL: Ignore updates while the user is typing to prevent cursor jumping/clearing\n    if (this._isEditing) {\n      return;\n    }\n    var rawValue = context.parameters.phoneNumber.raw || \"\";\n    var formattedValue = this.formatPhoneNumber(rawValue);\n    if (this._value !== formattedValue) {\n      this._value = formattedValue;\n      this._inputElement.value = formattedValue;\n      this.validateNumber(formattedValue);\n    }\n  }\n  getOutputs() {\n    return {\n      phoneNumber: this._value.replace(/[^0-9]/g, \"\")\n    };\n  }\n  destroy() {\n    this._inputElement.removeEventListener(\"input\", this.onInput.bind(this));\n    this._inputElement.removeEventListener(\"focus\", this.onFocus.bind(this));\n    this._inputElement.removeEventListener(\"blur\", this.onBlur.bind(this));\n  }\n  onFocus(event) {\n    this._isEditing = true;\n  }\n  onBlur(event) {\n    this._isEditing = false;\n    // On exit, ensure formatting is perfect and re-validate\n    var finalFormat = this.formatPhoneNumber(this._inputElement.value);\n    this._inputElement.value = finalFormat;\n    this.validateNumber(finalFormat);\n  }\n  onInput(event) {\n    var inputVal = this._inputElement.value;\n    var formatted = this.formatPhoneNumber(inputVal);\n    // Update input visually\n    if (inputVal !== formatted) {\n      this._inputElement.value = formatted;\n    }\n    this._value = formatted;\n    // Validate immediately\n    this.validateNumber(formatted);\n    this._notifyOutputChanged();\n  }\n  validateNumber(value) {\n    var rawDigits = value.replace(/[^0-9]/g, \"\");\n    // If empty, clear errors\n    if (rawDigits.length === 0) {\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any\n      this._context.utils.clearNotification(this._notificationId);\n      return;\n    }\n    // If less than 10 digits, SHOW ERROR\n    if (rawDigits.length < 10) {\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any\n      this._context.utils.setNotification(\"Invalid Phone Number: Must be exactly 10 digits.\", this._notificationId);\n    } else {\n      // eslint-disable-next-line @typescript-eslint/no-explicit-any\n      this._context.utils.clearNotification(this._notificationId);\n    }\n  }\n  formatPhoneNumber(value) {\n    if (!value) return \"\";\n    var phoneNumber = value.replace(/[^\\d]/g, \"\");\n    var len = phoneNumber.length;\n    if (len === 0) return \"\";\n    if (len < 4) return phoneNumber;\n    if (len < 7) return \"(\".concat(phoneNumber.slice(0, 3), \") \").concat(phoneNumber.slice(3));\n    return \"(\".concat(phoneNumber.slice(0, 3), \") \").concat(phoneNumber.slice(3, 6), \"-\").concat(phoneNumber.slice(6, 10));\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ccwisPhoneNumberFormate/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ccwisPhoneNumberFormate/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ccwis.ccwisPhoneNumberFormate', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ccwisPhoneNumberFormate);
} else {
	var ccwis = ccwis || {};
	ccwis.ccwisPhoneNumberFormate = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ccwisPhoneNumberFormate;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}